from django.shortcuts import render
from . models import Notes
from . forms import NoteForm
from django.views.generic import CreateView, ListView, DetailView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.urls import reverse_lazy
# Create your views here.


class NotesDeleteView(LoginRequiredMixin, DeleteView):
    model = Notes
    template_name = 'notes/notes_delete.html'
    success_url = reverse_lazy('notes:notes')
    # success_url = '/smart/notes/'
    login_url = "/login"

    def get_queryset(self):
        return self.request.user.notes.all()


class NotesUpdateView(LoginRequiredMixin, UpdateView):
    model = Notes
    success_url = '/smart/notes/'
    form_class = NoteForm
    login_url = "/login"

    def get_queryset(self):
        return self.request.user.notes.all()


class NotesCreateView(LoginRequiredMixin, CreateView):
    model = Notes
    success_url = reverse_lazy('notes:notes')  # '/smart/notes/'
    form_class = NoteForm
    login_url = "/login"

    def form_valid(self, form):
        form.instance.user = self.request.user  # attach logged-in user
        return super().form_valid(form)

        # self.object = form.save(commit=False)
        # self.object.user = self.request.user
        # self.object.save()
        # return HttpResponseRedirect(self.get_success_url())


class NotesListView(LoginRequiredMixin, ListView):
    model = Notes
    context_object_name = "notes"
    login_url = "/login"

    def get_queryset(self):
        return self.request.user.notes.all()
        # return Notes.objects.filter(user=self.request.user)  # self.request.user.notes.all()


class NotesDetailView(LoginRequiredMixin, DetailView):
    model = Notes
    context_object_name = "note"
    login_url = "/login"

    def get_queryset(self):
        return self.request.user.notes.all()
